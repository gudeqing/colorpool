xcmds
-----
* pip install dist/*gz

* example.py:
```
from colorpool import colorpool

colors = colorpool.get_color_pool(15)

```

See [document](https://gudeqing.github.io/colorpool/ "With a Title").
