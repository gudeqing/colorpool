xcmds
-----
* pip install dist/*gz

* example.py:
```
from colorpool import colorpool

colors = colorpool.ColorPool.get_color_poor(15)

```

See [document](https://gudeqing.github.io/colorpool/ "With a Title").
